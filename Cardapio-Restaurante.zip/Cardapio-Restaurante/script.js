 const pratos = [
    {
      nome: "X-Tudo",
      ingredientes: "Pão, hambúrguer, queijo, presunto, ovo, bacon, alface, tomate, milho e batata palha",
      preco: "R$ 25,00",
      imagem: "./img/gallery_8e735014-c9fa-4da4-849d-857c3a5efc74.jpg"
    },
    {
      nome: "X-Salada",
      ingredientes: "Pão, hambúrguer, queijo, alface, tomate e maionese",
      preco: "R$ 18,00",
      imagem: "./img/360_F_84285488_CaWrmiQ9xWJXFpCPMHD1r2ZYAzcESfkU.jpg"
    },
    {
      nome: "X-Frango",
      ingredientes: "Pão, frango grelhado, queijo, alface e molho especial",
      preco: "R$ 20,00",
      imagem: "./img/istockphoto-155160340-170667a.jpg"
    },
    {
      nome: "Hambúrguer com Cheddar",
      ingredientes: "Pão, hambúrguer artesanal e muito queijo cheddar",
      preco: "R$ 22,00",
      imagem: "https://source.unsplash.com/400x300/?cheddar-burger"
    },
    {
      nome: "Cachorro Quente",
      ingredientes: "Pão, salsicha, molho, milho, ervilha, batata palha e maionese",
      preco: "R$ 15,00",
      imagem: "https://source.unsplash.com/400x300/?hotdog"
    },
    {
      nome: "Pizza Havaiana (Especial)",
      ingredientes: "Molho de tomate, queijo, presunto e abacaxi",
      preco: "R$ 40,00",
      imagem: "https://source.unsplash.com/400x300/?hawaiian-pizza"
    }
  ];

  let index = 0;

  function mostrarPrato() {
    document.getElementById("imagem").src = pratos[index].imagem;
    document.getElementById("nome").innerText = pratos[index].nome;
    document.getElementById("ingredientes").innerText = pratos[index].ingredientes;
    document.getElementById("preco").innerText = pratos[index].preco;
  }

  function proximo() {
    index = (index + 1) % pratos.length;
    mostrarPrato();
  }

  function anterior() {
    index = (index - 1 + pratos.length) % pratos.length;
    mostrarPrato();
  }

  // Inicializa o primeiro prato
  mostrarPrato();